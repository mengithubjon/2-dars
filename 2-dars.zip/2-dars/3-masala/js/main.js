let a=prompt('a');
let b=prompt('b');

if ( (a==b)) {
    console.log(0);
}

if ( (a<b)) {
    console.log(b);
}


if ( (b<a)) {
    console.log(a);
}

