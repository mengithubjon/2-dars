let a = Number(prompt('a'));
if (a > 0 && a % 2 == 0) {
    console.log("bu son musbat juft son");
}
if (a > 0 && a % 2 == 1) {
    console.log("bu musbat toq son");
} if (a < 0 && a % 2 == 0) {
    console.log("bu son manfiy juft son");
}
if (a < 0 && a % 2 == -1) {
    console.log("bu son manfiy toq son");
}
if (a==0) {
    console.log(" bu son 0 ga teng");
}