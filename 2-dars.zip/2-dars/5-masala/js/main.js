let a = Number(prompt('a'));
if (a > 9 &&  a < 100 && a % 2 == 0) {
    console.log("bu son ikki xonali  juft son");
}
if (a > 9 && a<100 && a % 2 == 1) {
    console.log("bu son ikki xonali  toq son");
}
 if (a > 99 && a < 1000 && a % 2 == 0) {
    console.log("bu son uch xonali  juft son");
}
if (a > 99 && a < 1000 && a % 2 == 1) {
    console.log("bu son uch xonali toq son");
}
if (a==0) {
    console.log(" bu son 0 ga teng");
}