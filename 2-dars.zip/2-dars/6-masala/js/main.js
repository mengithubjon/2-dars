let a1 = +prompt("Pulingizni kiriting");
let b1 = prompt("Tashqarida bulsangiz  True qiymatini kiriting");
if (a1 >= 20 && b1 == "True" ) {
    console.log("True");
}
else {
    console.log("false");
}